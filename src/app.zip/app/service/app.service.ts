import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import * as environment from "../../../environment.json";
import { TransferState, makeStateKey } from "@angular/platform-browser";
import { of as observableOf, Observable } from "rxjs";
import { map } from "rxjs/operators";

@Injectable()
export class AppService {
  serverDate: any;
  ur: any;
  public getServerDate() {
    return this.serverDate;
  }

  public setServerDate(serverDate) {
    this.serverDate = serverDate;
  }
  constructor(private http: HttpClient, private transferState: TransferState) {}
  /**
   * Temporary method to handle url with or with out API Gateway changes
   * @param url
   */
  getUrl(url: string) {
    return url;
  }
  // Fetch Resource
  get(endpoint: string) {
    console.log("App Get Service: " + endpoint);
    endpoint = this.getUrl(endpoint);
    const COMPONENT_KEY = makeStateKey<string>(endpoint);
    if (this.transferState.hasKey(COMPONENT_KEY)) {
      const res = this.transferState.get(COMPONENT_KEY, null);
      this.transferState.remove(COMPONENT_KEY);
      return observableOf(res);
    } else {
      let _headers = new HttpHeaders();
      _headers.append("Content-Type", "application/hal+json");
      // return this.http.get((<any>environment).nodeUrl + endpoint, {
      //   headers: _headers
      // });

      return this.http
        .get((<any>environment).nodeUrl + endpoint, { headers: _headers })
        .pipe(
          map(response => {
            if (!endpoint.includes("alias")) {
              //console.log("Transfer KEy!!!: ");
              this.transferState.set(COMPONENT_KEY, response);
            }
            return response;
          })
        );
    }
    //return this.http.get(endpoint,{headers: _headers});
  }

  // Create Resource
  post(endpoint: string, bo: any) {
    console.log("App Post Service: " + endpoint);
    let _headers = new HttpHeaders();
    _headers.append("Content-Type", "application/json");
    console.log("Body data Service: " + JSON.stringify(bo));

    return this.http.post((<any>environment).nodeUrl + endpoint, {
      bo,
      header: _headers
    });
  }
}
