import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { AppService } from "./app.service";

@Injectable()
export class RoutesService {
  constructor(private _service: AppService) {
    //super();
  }

  public Find(apiUrl): Observable<any[]> {
    let url = "/" + apiUrl;
    return this._service.get(url).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
