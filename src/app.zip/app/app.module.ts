import {
  BrowserModule,
  BrowserTransferStateModule
} from "@angular/platform-browser";
import { NgModule } from "@angular/core";
//import { HttpModule } from "@angular/http";
import { HttpClientModule } from "@angular/common/http";
import { AppComponent } from "./app.component";
import { HeaderComponent } from "./Widget/header/header.component";
import { FooterComponent } from "./Widget/footer/footer.component";
import { AppService } from "./service/app.service";
import { RoutesService } from "./service/routes.service";
import { RouterModule } from "@angular/router";
import { appRoutes } from "./app-router";
import { BlogListComponent } from "./Widget/blog-list/blog-list.component";
import { SocialComponent } from "./Widget/social/social.component";
import { GlobalComponent } from "./Widget/global/global.component";
import { AppWidgetDirective } from "./app.widget.directive";
import { BlogViewComponent } from "./Widget/blog-view/blog-view.component";
import { BlogCategoryComponent } from "./Widget/blog-category/blog-category.component";
import { HomeComponent } from "./Widget/home/home.component";
import { PagerComponent } from "./elements/pager/pager.component";
import { LoadMoreComponent } from "../app/shared/component/loadmore/loadmore.component";
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BlogListComponent,
    SocialComponent,
    GlobalComponent,
    AppWidgetDirective,
    BlogViewComponent,
    BlogCategoryComponent,
    HomeComponent,
    PagerComponent,
    LoadMoreComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: "my-appg" }),
    BrowserTransferStateModule,
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    HttpClientModule
  ],
  entryComponents: [BlogListComponent, SocialComponent],
  providers: [AppService, RoutesService],
  bootstrap: [AppComponent]
})
export class AppModule {}
