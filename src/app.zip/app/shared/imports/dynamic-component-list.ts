//import all widget under Component...
import { BlogListComponent } from "../../Widget/blog-list/blog-list.component";
import { SocialComponent } from "../../Widget/social/social.component";

export class DynamicComponentList {
  public static list = [
    {
      Name: "Blog List",
      Key: "blog_list",
      component: BlogListComponent
    },
    {
      Name: "Social Media",
      Key: "social_media",
      component: SocialComponent
    }
  ];

  public static getList(): any[] {
    return this.list;
  }
}
