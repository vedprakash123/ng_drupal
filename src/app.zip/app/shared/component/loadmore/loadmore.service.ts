
import { of as observableOf, from as observableFrom, Observable } from 'rxjs';

import { take, skip } from 'rxjs/operators';
import { Injectable } from "@angular/core";
import { map } from "rxjs/operators";

@Injectable()
export class LoadMoreService {
  constructor() { }
  LoadMoreData(data, FinalData, pageIndex, pageSize): Observable<any> {
    let result = FinalData ? FinalData : [];
    observableFrom(data).pipe(
      skip(pageIndex),
      take(pageSize))
      .subscribe(res => {
        result.push(res);
      });
    return observableOf(result);
  }
}
