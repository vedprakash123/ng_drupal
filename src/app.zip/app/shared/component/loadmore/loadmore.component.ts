import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { LoadMorePaginationModal } from "../../../../app/Model/loadmore";
import { LoadMoreInterface } from "../../../../app/Model/loadmore";
import { LoadMoreService } from "../../../shared/component/loadmore/loadmore.service";
@Component({
  selector: "loadmore",
  templateUrl: "./loadmore.component.html",
  styleUrls: ["./loadmore.component.css"],
  providers: [LoadMoreService]
})
export class LoadMoreComponent implements OnInit {
  public loadmore = new LoadMorePaginationModal();

  pages: number[] = [];

  constructor(private _loadMoreService: LoadMoreService) {}

  @Output() pageChange: EventEmitter<number> = new EventEmitter<number>();

  @Input() set pageCurrent(current: number) {
    this.loadmore.CurrentPage = current;
  }

  @Input() set itemsPerPage(items: number) {
    this.loadmore.ItemsPerPage = items;
  }

  @Input() set pageCount(count: number) {
    this.loadmore.TotalPages = count;
    this.pages = [];

    for (let index = 0; index < this.loadmore.TotalPages; index++) {
      this.pages.push(index);
    }
  }

  onPageChange(page: number) {
    this.pageChange.emit(page);
    this.loadmore.CurrentPage = page;
  }

  onPageChangeL(page: number) {
    console.log("Kukka Kukka!!", page);
    this.pageChange.emit(page);
    this.loadmore.CurrentPage = page + 1;
    // this._loadMoreService.LoadMoreData("ved", "prekash", 1, 5);
  }

  ngOnInit() {}
}
