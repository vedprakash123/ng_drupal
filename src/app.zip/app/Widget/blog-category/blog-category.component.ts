import { Component, OnInit } from "@angular/core";
import { RoutesService } from "../../service/routes.service";
import { CATEGORY_LIST_API_URL } from "../../../constants/apiUrl.constants";

@Component({
  selector: "blog-category",
  templateUrl: "./blog-category.component.html",
  styleUrls: ["./blog-category.component.css"]
})
export class BlogCategoryComponent implements OnInit {
  CategoryList: any;
  count = 0;
  constructor(private routesService: RoutesService) {}

  ngOnInit() {
    this.init(0);
  }

  private init(page: number) {
    let apiUrl = CATEGORY_LIST_API_URL + "&pager=" + page;
    return this.routesService.Find(apiUrl).subscribe((response: any) => {
      this.CategoryList = response;
    });
  }

  onPageChange(page: number) {
    this.init(page);
  }

  onPageChangeL(pages: number) {
    console.log("Pukka!!!", pages);
    //let pp = 0;
    //let resp = this.init(pp + 1);
    this.count += 1;
    console.log("Counter!!!", this.count);
    if (pages >= this.count) {
      let resp = this.init(this.count);
      console.log("Counter: ", this.count);
    } else {
      console.log("Length exceeded!! ");
    }
  }
}
