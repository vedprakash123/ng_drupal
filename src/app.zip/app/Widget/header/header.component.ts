import { Component, OnInit } from "@angular/core";
import { RoutesService } from "../../service/routes.service";
import { SOCIAL_MEDIA_API_URL } from "../../../constants/apiUrl.constants";
@Component({
  selector: "header-component",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"]
})
export class HeaderComponent implements OnInit {
  SocialMedia: any;
  constructor(private routesService: RoutesService) {}

  ngOnInit() {
    this.routesService.Find(SOCIAL_MEDIA_API_URL).subscribe((response: any) => {
      this.SocialMedia = response;
    });
  }
}
