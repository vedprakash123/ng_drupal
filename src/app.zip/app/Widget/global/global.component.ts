import {
  Component,
  OnInit,
  ViewChild,
  ComponentFactoryResolver,
  ElementRef
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { RoutesService } from "../../service/routes.service";
import { DynamicComponentList } from "../../shared/imports/dynamic-component-list";
import { PageComponentListModel } from "../../Model/pagecompoentlist.model";
import { AddWidget } from "../../Model/addwidget.model";
import { AppWidgetDirective } from "../../app.widget.directive";
import { AppWidgetComponent } from "../../Model/app.widget.component";
import { ALIAS_API_URL } from "../../../constants/apiUrl.constants";

@Component({
  selector: "global.component",
  templateUrl: "./global.component.html",
  styleUrls: ["./global.component.css"]
})
export class GlobalComponent implements OnInit {
  pageNodeId: any;
  public current_url: any;
  private AppComponentList = DynamicComponentList.getList();
  private PageComponentList: Array<PageComponentListModel> = [];
  private widget: AddWidget[];
  @ViewChild(AppWidgetDirective, { read: AppWidgetDirective, static: false })
  appDirective: AppWidgetDirective;
  constructor(
    private _router: Router,
    private _routerService: RoutesService,
    private componentFactoryResolver: ComponentFactoryResolver,
    private _activatedRoute: ActivatedRoute,
    private elRef: ElementRef
  ) {
    //super();
    this.PageComponentList = [];
    this.FindAppRoutes();
    this.MyAppRoutes = [];
  }

  ngOnInit() {
    console.log("Entered Here!!!");
  }

  private Bind(currentRouteInfo: any): void {
    //Node Id for getting ticker
    this.pageNodeId = currentRouteInfo.Nid;
    //console.log("Component List::", currentRouteInfo);
    //console.log("Component Bind EndPoint::", currentRouteInfo.EndPoint);
    this._routerService
      .Find(currentRouteInfo.EndPoint)
      .subscribe((response: any) => {
        console.log("Component Bind::", response);
        this.createComponentsDynamically(response);
      });
  }

  private createComponentsDynamically(result: any) {
    //console.log("Component List::", result);
    let contentBody = result;
    //console.log("Component Body::", contentBody);
    if (contentBody) {
      this.FindPageComponentList(contentBody.data.component);
    }
  }

  private FindPageComponentList(componentData) {
    console.log("Component Body::", componentData);
    componentData.forEach((item: any) => {
      if (item != null && item !== "") {
        let result = this.FilterFromWidgetList(item);
        console.log("Component Body Results::", item);
        if (result != undefined && result.length > 0) {
          this.PageComponentList.push(
            new PageComponentListModel(
              result[0].Name,
              result[0].component,
              item,
              false
            )
          );
        }
      }
    });
    this.widget = this.GetMyWidgets(this.PageComponentList);
    this.widget.forEach((widgetItem: AddWidget) => {
      this.LoadComponent(widgetItem);
    });
  }

  private FilterFromWidgetList(item: any) {
    console.log("Item Uppercase::", item.Name.toUpperCase());
    return this.AppComponentList.filter(widgetItem => {
      console.log("Widget Key::", widgetItem.Key.toUpperCase());
      return widgetItem.Key.toUpperCase() == item.Name.toUpperCase();
    });
  }

  private LoadComponent(widgetItem: AddWidget) {
    console.log("Widget:: ", widgetItem);
    setTimeout(() => {
      let componentFactory = this.componentFactoryResolver.resolveComponentFactory(
        widgetItem.component
      );
      console.log("this.appDirective:: ", this.appDirective);
      let viewContainerRefl = this.appDirective.viewContainerRef;
      let componentRef = viewContainerRefl.createComponent(componentFactory);
      (<AppWidgetComponent>componentRef.instance).data = widgetItem.data;
      componentRef.changeDetectorRef.detectChanges();
    }, 0);
  }

  private GetMyWidgets(pagecompoentlist: any) {
    let result = [];
    pagecompoentlist.forEach((item: PageComponentListModel) => {
      result.push(new AddWidget(item.Widget, item.Data));
    });
    return result;
  }
  //private MY_ROUTE: string = "MY_ROUTE";
  private MyAppRoutes: Array<any>;

  private FindAppRoutes() {
    console.log("Loading............:: ");
    //console.log("API URL :: ", apiUrl);
    this._routerService.Find(ALIAS_API_URL).subscribe((data: any) => {
      let urlAliasData = data || {};
      console.log("All Aliases:: ", urlAliasData);
      let bodyData = urlAliasData;
      if (bodyData) {
        this.mapUrlAliasDetails(bodyData);
      }
    });
  }

  private mapUrlAliasDetails(data: any) {
    //if (data.Items !== "undefined") {
    //console.log("Items:: ", data.Items);
    //}
    this.ManagedynamicRoute(data.Items);
  }

  private ManagedynamicRoute(routeData) {
    //debugger;
    routeData.forEach((item: any) => {
      //let pukka = item.UrlAlias.substr(1);
      //console.log("Parsed JSON Data:: ", item.alias);
      //adding routes explicitly to handle back button ->home
      /*if (item.type == "home") {
        this.MyAppRoutes.push({
          path: '',
          component: GlobalComponent,
          data: { "EndPoint": item.EndPoint }
        });
      } */
      console.log("Item Type" + item.alias);
      //if (item.alias === "alias") {
      this.MyAppRoutes.push({
        path: item.alias,
        component: GlobalComponent,
        data: { EndPoint: item.end_point }
      });
      //}
    });
    //adding route to handle unpublised url
    // this.MyAppRoutes.push({
    //   path: "**",
    //   component: GlobalComponent
    // });

    this._router.resetConfig(this.MyAppRoutes);
    this.BindRoutes(routeData);
    //this._service.ManageSmartBanner(this.IsMobileViewPort, this.IsTabletViewPort);
  }

  private BindRoutes(data: any) {
    //console.log("All Aliases Data:: ", data);
    this._activatedRoute.data.subscribe((item: any) => {
      //get the current browser url to route accordingly
      //this.current_url = this._router.routerState.snapshot.url;
      //let queryParam = this._activatedRoute.snapshot.queryParams;

      let currentUrl = this._router.routerState.snapshot.url;

      let endPointInfo;
      endPointInfo = this.getAPIEndPoint(data, currentUrl.slice(1));
      //To map to the component corresponding to type as home
      //console.log("outer1::", data);
      //console.log("outer2::", currentUrl);
      //console.log("outer3::", endPointInfo);
      //console.log("outer4::", endPointInfo);
      if (endPointInfo != null) {
        this.Bind({
          EndPoint: endPointInfo.end_point,
          Nid: endPointInfo.alias
        });
        // Removed searchKey...
      }
    });
  }

  /**
   * Get endpoint (api url) for respective browser url
   * if empty url "x.com/" then load homepage
   * for anyother url get endpoint
   * if endpoint not found call pagenotfound api
   * @param data
   * @param currentUrl
   */
  private getAPIEndPoint(data: any, currentUrl: string) {
    let pagedata = this.FindApiEndPoint(data, currentUrl);
    //console.log("PageData::", pagedata);
    return pagedata;
  }

  private FindApiEndPoint(data: any, alias: string) {
    //console.log("FAEP1::", data);
    //console.log("FAEP1Data::", alias);
    let result = data.filter((item: any) => {
      //console.log("Kukka1");
      return item.alias == alias;
    });
    //console.log("Puka::", result);
    return result[0];
  }
}
