import { Component, OnInit, Input } from "@angular/core";
import { RoutesService } from "../../service/routes.service";

@Component({
  selector: "app-social",
  templateUrl: "./social.component.html",
  styleUrls: ["./social.component.css"]
})
export class SocialComponent implements OnInit {
  @Input() data: any;
  Social: any;
  constructor(private routesService: RoutesService) {}

  ngOnInit() {
    if (this.data && this.data.Api != undefined) {
      this.routesService.Find(this.data.Api).subscribe((response: any) => {
        this.Social = response;
      });
    }
  }
}
