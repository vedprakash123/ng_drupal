import { Component, OnInit } from "@angular/core";
import { RoutesService } from "../../service/routes.service";
import { ActivatedRoute } from "@angular/router";
import { BLOG_LIST_API_URL } from "../../../constants/apiUrl.constants";
@Component({
  selector: "home-component",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit {
  BlogListing: any;
  page: any;

  constructor(
    private _route: ActivatedRoute,
    private routesService: RoutesService
  ) {}

  ngOnInit() {
    let page = 0;
    this.onPageChange(page);
  }

  onPageChange(page) {
    let apiUrl = BLOG_LIST_API_URL + "&page=" + page + "&id=all";
    this.routesService.Find(apiUrl).subscribe((response: any) => {
      this.BlogListing = response;
    });
  }
}
