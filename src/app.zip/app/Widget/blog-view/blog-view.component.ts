import { Component, OnInit } from "@angular/core";
import { RoutesService } from "../../service/routes.service";
import { ActivatedRoute } from "@angular/router";
import * as API_ENDPOINT from "../../../constants/apiUrl.constants";
@Component({
  selector: "blog-view",
  templateUrl: "./blog-view.component.html",
  styleUrls: ["./blog-view.component.css"]
})
export class BlogViewComponent implements OnInit {
  BlogContent: any;
  alias: string;
  constructor(
    private _route: ActivatedRoute,
    private routesService: RoutesService
  ) {}

  ngOnInit() {
    this._route.paramMap.subscribe(params => {
      this.alias = params.get("alias");
      const apiUrl = API_ENDPOINT.BLOG_VIEW_API_URL + this.alias;
      this.routesService.Find(apiUrl).subscribe((response: any) => {
        this.BlogContent = response;
      });
    });
  }
}
