import { Component, OnInit, Input } from "@angular/core";
import { RoutesService } from "../../service/routes.service";
import { ActivatedRoute } from "@angular/router";
import { BLOG_LIST_API_URL } from "../../../constants/apiUrl.constants";

@Component({
  selector: "blog-list",
  templateUrl: "./blog-list.component.html",
  styleUrls: ["./blog-list.component.css"]
})
export class BlogListComponent implements OnInit {
  @Input() data: any;
  BlogListing: any;
  term: any;
  constructor(
    private _route: ActivatedRoute,
    private routesService: RoutesService
  ) {}

  ngOnInit() {
    this._route.paramMap.subscribe(params => {
      this.term = params.get("term");
      if (this.term != undefined) {
        this.data = true;
        this.data = {
          Api: BLOG_LIST_API_URL + "&id=/category/" + this.term
        };
      }
      if (this.data && this.data.Api != undefined) {
        this.routesService.Find(this.data.Api).subscribe((response: any) => {
          this.BlogListing = response;
        });
      }
    });
  }
}
