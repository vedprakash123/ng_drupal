export interface AppWidgetComponent {
  data: any;
  
}
