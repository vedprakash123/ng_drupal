/*export interface LoadMoreInterface {
  Data: any[];
  FinalData: any[];
  PageIndex: number;
  PageSize: number;
  LoadMoreData();
} 

export class LoadMorePaginationModal {
  public CurrentPage: number = 0;
  public TotalItems: number = 0;
  public TotalPages: number = 0;
  public PageIndex: number = 0;
}
"CurrentPage":0,
"TotalItems":"15",
"TotalPages":3,
"ItemsPerPage":5
*/

// export class LoadMorePaginationModal {
//   public _pageCurrent: number = 0;
//   public TotalItems: number = 0;
//   public _pageCount: number = 0;
//   public PageIndex: number = 0;
// }

export class LoadMorePaginationModal {
  public CurrentPage: number = 0;
  public TotalItems: number = 0;
  public TotalPages: number = 0;
  public ItemsPerPage: number = 0;
}

export interface LoadMoreInterface {
  Data: any[];
  FinalData: any[];
  PageIndex: number;
  PageSize: number;
  LoadMoreData();
}
// export this load more modal in blog category list
